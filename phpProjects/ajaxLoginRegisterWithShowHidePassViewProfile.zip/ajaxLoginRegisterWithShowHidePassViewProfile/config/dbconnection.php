<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ajaxloginregistration";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>